
                <div class="container-fluid">
                    <!-- Page Heading -->
                   
                    <div class="card card-stepper shadow mb-4">
                        <div class="card-header py-3  ">
                        <h6 class="m-0 font-weight-bold ">Order No :<span> 0018655</span></h6>
                        </div>
                        
                        <div class="card-body">

                <!-- date and strap form -->
                <div class="tab-content ml-2">
                  <div class="tab-pane active" role="tabpanel" id="info">
                  <div class=" pb-0 d-flex justify-content-between ">
                        <h6 class="m-0 font-weight-bold ">Date :<span> 14/11/2023</span></h6>

                       
                        </div>
                        <div class="row d-flex  h-100">
                        
                        <div class="col-md-12 mt-4">
                        <div class="card card-stepper" >
                          <div class="card-header pt-2 pb-2 pl-3 pr-3">
                              <div>
                                <h6 class="mb-0">Order Overview </h6>
                            </div>
                          </div>
                          <table class="table table-bordered" style="width: 100%">
                          <tr>
                                <td><b>Sl. No. :</b> 01</td>
                                <td><b>Sample REf :</b> 7687</td>
                                <td><b>Sample REQ Date :</b> 14-11-2023</td>
                                <td><b>TSP REF :</b> 9866478</td>
                            </tr>
                            <tr>
                                <td><b>QTY : </b> 03</td>
                                <td><b>Delivery Address : </b> Pawan Nagar </td>
                                <td><b>Estimated Dispatch Date : </b> 16-11-2023</td>
                                <td><b>Confirmed Dispatch Date : </b> 17-11-2034</td>
                            </tr>
                            <tr>
                                <td><b>Courier Name : </b> DHL</td>
                                <td><b>AWB : </b> 7687</td>
                                <td><b>Remarks : </b> abc</td>
                            </tr>
                           
                           
                          </table>
                       
                          <!-- <div class="card-body p-4">
                            <div class="d-flex flex-row mb-1 pb-2">
                              <div class="flex-fill">
                             <div class="row">
                                <div class="col-sm-4">
                              <p class="text-muted-1">Sl. No. : <span class="text-body">01</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Sample REf  : <span class="text-body">947839</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Sample REQ Date: <span class="text-body">15/11/2023</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">TSP REF : <span class="text-body">5678879</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">QTY : <span class="text-body">03</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Delivery Address : <span class="text-body">abc</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Estimated Dispatch Date : <span class="text-body">abc</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Confirmed Dispatch Date : <span class="text-body">FOB</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Courier Name : <span class="text-body">13/11/2023</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">AWB : <span class="text-body">13/11/2023</span></p>
                              </div>
                              <div class="col-sm-4">
                              <p class="text-muted-1">Remarks : <span class="text-body">abc</span></p>
                                </div>
                              </div>
                              </div>
                            </div>
                          </div> -->
                          
                        </div>
                      </div>
                     
                      
                     
                    </div>
                  </div>
                
                           </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- End of Main Content -->
