<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Orders extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->database();
		$this->load->model('Orders_model', 'orders', TRUE);
    }
    public function index()
    {
       
        $data['order_data'] = $this->orders->getGeneralOrderData();
        $this->load->view('comman/header');
        $this->load->view('all_orders',$data);
        $this->load->view('comman/footer');
    }

    public function searchData()
    {
        $searchOrderID = $this->input->post('searchOrderID');
        $data['searchOrderID'] = $searchOrderID;
        // $data['order_data'] = $this->orders->getGeneralOrderData();
        if($searchOrderID){
            $data['order_data'] = $this->orders->getSpecificOrderData($searchOrderID);
        }else {
            // echo '<h5 class="text-center mt-2">No Record Found!</h5>';
            $data['order_data'] = $this->orders->getGeneralOrderData();
        }
        $this->load->view('filterd_orders',$data);
    }

    // public function searchData()
    // {
    //     $searchOrderID = $this->input->post('searchOrderID');
    //     $data['searchOrderID'] = $searchOrderID;

    //     $data['order_data'] = $this->orders->getGeneralOrderData();
    //     $data['order_data'] = $this->orders->getSpecificOrderData($searchOrderID);
    //     $this->load->view('filterd_orders',$data);
    // }

    public function Completed()
    {
        $data['order_data'] = $this->orders->getGeneralOrderData();
        $this->load->view('comman/header');
        $this->load->view('completed_orders',$data);
        $this->load->view('comman/footer');
    }

    public function Sample()
    {
        $data['all_sample_req'] = $this->orders->allSampleRequestData();

        $this->load->view('comman/header');
        $this->load->view('sample_orders',$data);
        $this->load->view('comman/footer');
    }
    public function SampleOrders()
    {
        $this->load->view('comman/header');
        $this->load->view('sample_order_details');
        $this->load->view('comman/footer');
    }
    public function dispatchOrder()
    {
        $confirm_dis_order = $this->input->post('confirm_dis_order');
        $confirm_complete_order = $this->input->post('confirm_complete_order');
        $order_id = $this->input->post('order_id');
        $order_id2 = $this->input->post('order_id2');
        $this->db->query("UPDATE `orders` SET `status`= ? WHERE `order_id`= ?", array($confirm_dis_order, $order_id));
        $this->db->query("UPDATE `orders` SET `status`= ? WHERE `order_id`= ?", array($confirm_complete_order, $order_id2));
    //     echo "<script>alert('order update successfully');
    //     window.location.href = '".site_url('Orders')."';
    //    </script>";
    $this->session->set_flashdata('success', "order update successfully");
    redirect('Orders');
    }

}
?>