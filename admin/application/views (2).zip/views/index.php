
<style>
    .col-sm-4 {
    flex: 0 0 33.33333%;
    max-width: 33% !important;
    
}
.cardd{
    box-shadow: 0px 0px 15px #E3E6F0;
    border-radius:10px;
    padding: 5px;
    margin-top:20px;
}
</style>

<input type="text" value="1" id="addfields" hidden>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-1 ml-1">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                        <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-3 col-md-6 mb-2">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            <?php 
                                             echo $all_staff;
                                             ?> 
                                            <!-- 30 -->
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">Total Staff</div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-2">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            <?php 
                                                echo $sample_count;
                                                ?> 
                                                <!-- 500 -->
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">Sample Requests </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-2">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <?php
                                                    echo $all_pending_count;
                                                    ?>
                                           
                                            <!-- 200 -->
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">Pending Orders</div>
                                                </div>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php 
                        if($this->session->userdata('type') != 'Sales') { ?>
                            <div class="col-xl-3 col-md-6 mb-2">
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                <?php
                                                    echo $all_transit_count;
                                                    ?>
                                                     <!-- 0 -->
                                                    </div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">Transit Details </div>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php }
                        ?>
                        
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="dashboard-form">
                                <div class="form-heading" id="order">
                                    <h1 class="h3 mb-0 text-gray-800">Create Order</h1>
                                    <!-- <button onclick="addForm()"> add form </button> -->
                                </div>
                                <div class="switchBtn d-flex">
                                     <div class="form-check">
                                    <input type="radio" class="form-check-input"  id="radio1" onchange="hideB(this)" name="optradio" value="option2" checked>General Order 
                                    <label class="form-check-label" for="radio2"></label>
                                    </div>
                                     <div class="form-check">
                                    <input type="radio" class="form-check-input" id="radio2" onchange="hideA(this)" name="optradio" value="option1" >Sample Request
                                    <label class="form-check-label" for="radio1"></label>
                                    </div>
                                   
                                </div>
                                <form id="frm" method="post" action="<?php echo site_url('Home/addSampleRequestData')?>" style="display:none">
                                    
                                <div class="row">
                                <div class="col-md-4 input-container">           
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <select class="form-control" name="full_name" onchange="change_customer(this.value)" id="customer_data" required>
                                    <option >Select Name</option>
                                    <?php 
                                        foreach ($all as $value) { ?>
                                        <option value="<?php echo $value['customer_id']?>"><?php echo $value['customer_name']; ?></option>
                                        <?php }
                                        ?>
                                    </select>

                                   </div>

                                </div>
                              
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Contact No" id="contact_no" name="contact_no" required>
                                   </div>
                                
                                </div>
                                <!-- <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Contact No" name="contact_no" 
                                        pattern="[0-9]{10}"
                                        oninvalid="this.setCustomValidity('Please Enter Correct Contact No')"
                                        oninput="this.setCustomValidity('')" required>
                                   </div>
                                
                                </div> -->
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input type="email" class="form-control" placeholder="Enter Email" name="email" id="customer_email" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Sample Ref" name="sample_ref" required>
                                   </div>
                               
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Sample Req Date" 
                                        onfocus="(this.type='date')" onblur="(this.type='text')" name="sample_req_date" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                        <input type="number" class="form-control" placeholder="Enter Tsp Ref" name="tsp_ref" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                        <input type="number" class="form-control" placeholder="Enter QTY" name="qty" required>
                                   </div>
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Delivery Address" name="delivery_address" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Estimated Dispatch Date" name="estimated_dispatch_date"
                                         onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Confirmed Dispatch Date" name="confirmed_dispatch_date"
                                        onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-ship"></i></span>
                                    <select class="form-control" name="courier_name" required>
                                    <option >Courier Name</option>
                                    <option value="UPS">UPS</option>
                                    <option value="DHL">DHL</option>
                                    <option value="Fedex">Fedex</option>
                                    <option value="TNT">TNT</option>
                                    <option value="Blue Dart">Blue Dart</option>
                                    <option value="Professional">Professional</option>
                                    </select>
                                   </div>

                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-plane"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter AWB " name="awb" required>
                                   </div>
                                
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-comment"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Remarks" name="remarks" required>
                                   </div>
                                </div>
                                <div class="col-md-12">
                                <div class="formBtn">
                                 <button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
                                </div>
                                </div>
                            </div>
                            </form>
                            <form id="frm2" action="<?php echo site_url('Home/addGeneralOrderData') ?>" method="post">
                            <div class="cardd">
                            <input type="text" name="count" value="0" id="count" hidden>

                            <div class="row">
                            <div class="col-md-4 input-container">           
                                <div class="input-icons">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    
                                    <select class="form-control" name="full_name0" onchange="change_customer_data(this.value)" id="customer_data01" required>
                                    <option >Select Name</option>
                                    <?php 
                                        foreach ($all as $value) { ?>
                                        <option value="<?php echo $value['customer_id']?>"><?php echo $value['customer_name']; ?></option>
                                        <?php }
                                        ?>
                                    </select>
                                   </div>

                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Contact No" name="contact_no0" id="contact_no01" value="" required>
                                   </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input type="email" class="form-control" placeholder="Enter Email" name="customer_email0" id="customer_email01" value="" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="text" class="form-control"  placeholder="Enter Shipment No." name="shipment_no0" required>
                                </div>                                                                
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PO Received Date" name="po_received_date0"
                                onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dispatch Date" name="dispatch_date0"
                                onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-comments"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Remarks" name="remarks0" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-text-width"></i></span>
                                <select class="form-control" name="size_fcl0" required>
                                    <option >SIZE-FCL </option>
                                    <option value="AIR">AIR</option>
                                    <option value="LCL">LCL</option>
                                    <option value="20' FCL">20' FCL</option>
                                    <option value="40' FCL">40' FCL</option>
                                    </select>
                                </div>
                                </div>
                                </div>
                                <hr>
                                <div class="row">
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no0[]" required>
                                </div>
                                </div>
                              
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external0[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="number" class="form-control" placeholder="Enter QTY" name="qty0[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-cube"></i></span>
                                <input type="number" class="form-control" placeholder="Enter Packing" name="packing0[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class='fa fa-dot-circle-o'></i></span>
                                <input type="number" class="form-control" placeholder="Enter Pallets" name="pallets0[]" required>
                                </div>
                                </div>
                               
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-line-chart"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales0[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-ship"></i></span>
                                <select class="form-control" name="shipment_term0[]" required>
                                    <option>Shipment Term</option>
                                    <option value="FOB">FOB</option>
                                    <option value="CIF">CIF</option>
                                    <option value="DDU">DDU</option>
                                    </select>
                                </div>
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-money"></i></span>
                                <input type="number" class="form-control" placeholder="Price" name="price0[]" required>
                                </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-md-12 text-right">
                                <a type="button" onclick="addData('addfieldsContainer0')" style="color:#4e73df; margin:5px;"> <u><b> Add More Fields </b></u></a>
                                </div>
                                <div id="addfieldsContainer0" class="col-md-12 add-fields-container"> </div>
                                </div>
                                </div> 
                               
                                
                                <!-- <div class="cardd"> -->
                            <!-- <div class="row">
                            <div class="col-md-4 input-container">           
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <select class="form-control">
                                    <option>Aniket Patil</option>
                                    <option>Jitendra Jadhav</option>
                                    <option>Dinesh Mahajan</option>
                                    </select>
                                   </div>

                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Contact No" value="9876543256" name="contact_no">
                                   </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input type="email" class="form-control" placeholder="Enter Email" value="aniket@gmail.com" name="email">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="number" class="form-control"  placeholder="Enter Shipment No." name="shipment_no">
                                </div>                                                                
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PO Received Date" name="received_date"
                                onfocus="(this.type='date')" onblur="(this.type='text')">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dispatch Date" name="dispatch_ate"
                                onfocus="(this.type='date')" onblur="(this.type='text')">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-comments"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Remarks" name="remarks">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-text-width"></i></span>
                                <select class="form-control">
                                    <option>SIZE-FCL </option>
                                    <option>AIR</option>
                                    <option>LCL</option>
                                    <option>20' FCL</option>
                                    <option>40' FCL</option>
                                    </select>
                                </div>
                                </div>
                                 </div>
                                <hr>
                                <div class="row">
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no">
                                </div>
                                </div>
                              
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="number" class="form-control" placeholder="Enter QTY" name="QTY">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-cube"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Packing" name="packing">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class='fa fa-dot-circle-o'></i></span>
                                <input type="text" class="form-control" placeholder="Enter Pallets" name="pallets">
                                </div>
                                </div>
                               
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-line-chart"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-ship"></i></span>
                                <select class="form-control">
                                    <option>Shipment Term</option>
                                    <option value="FOB">FOB</option>
                                    <option value="CIF">CIF</option>
                                    <option value="DDU">DDU</option>
                                    </select>
                                </div>
                                </div>
                          </div> -->

                                <!-- <div class="row">
                                <div class="col-md-12 text-right">
                                <a type="button" onclick="addData('addfieldsContainer3')" style="color:#4e73df; margin:5px;"> <u> Add More Fields </u></a>
                                </div>
                                <div id="addfieldsContainer3" class="col-md-12 add-fields-container"> </div>
                                </div>
                                </div> -->

                                <!-- <div id="addforms"></div> -->

                                <div id="test_div">  </div>
                                <div class="col-md-12" >
                                <div class="formBtn d-flex justify-content-end" id="formbtn">
                                <button type="button" class="btn btn-success " onclick="addForm()">Add Shipment</button>
                                <!-- <button type="button" class="btn btn-success" onclick="addform()">Add Shipment</button> -->
                                 <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                </div>

                            </form>
                        </div>
                    </div>
                    </div>
                </div>

            </div>

<script>
  
  function change_customer() {
        var selectedIndex = document.getElementById('customer_data').selectedIndex;
        var contact_no = document.getElementById('contact_no');
        var customer_email = document.getElementById('customer_email'); // Assuming you have an element with id 'customer_email'

        // Assuming your PHP array is named $all and contains the customer_contact and customer_email fields
        var customerData = <?php echo json_encode($all); ?>;

        // Make sure the selectedIndex is greater than 0 and within the bounds of the array
        if (selectedIndex > 0 && selectedIndex <= customerData.length) {
            // Set the contact number and email based on the selected customer's data
            contact_no.value = customerData[selectedIndex - 1].customer_contact;
            customer_email.value = customerData[selectedIndex - 1].customer_email;
        } else {
            // Handle the case where no option is selected or the index is out of bounds
            contact_no.value = '';
            customer_email.value = '';
        }
    }
</script>

<script>
  
  function change_customer_data() {
        var selectedIndex = document.getElementById('customer_data01').selectedIndex;
        var contact_no = document.getElementById('contact_no01');
        var customer_email = document.getElementById('customer_email01'); // Assuming you have an element with id 'customer_email'

        // Assuming your PHP array is named $all and contains the customer_contact and customer_email fields
        var customerData = <?php echo json_encode($all); ?>;

        // Make sure the selectedIndex is greater than 0 and within the bounds of the array
        if (selectedIndex > 0 && selectedIndex <= customerData.length) {
            // Set the contact number and email based on the selected customer's data
            contact_no.value = customerData[selectedIndex - 1].customer_contact;
            customer_email.value = customerData[selectedIndex - 1].customer_email;
        } else {
            // Handle the case where no option is selected or the index is out of bounds
            contact_no.value = '';
            customer_email.value = '';
        }
    }
</script>
<script>
    
    function addForm() {
        addcount = $('#addfields').val();
        countIncrement = $('#count').val();
        $.ajax({
            type: 'POST',
            url: "<?php echo site_url('CompletedOrder/generalOrder'); ?>",
            datatype: "html",
            data :{
                addcount: addcount,
                countIncrement: parseInt(countIncrement) + 1
            },
            success: function (data){
                
                $('#test_div').append(data);
                $('#addfields').val(parseInt(addcount)+1);
                $('#count').val(parseInt(countIncrement)+1);
            }
        })
    }
    </script>


            <script>

var serialNumbers = {};

function addData(containerId) {
    var count = $('#count').val();
    serialNumbers[containerId] = serialNumbers[containerId] || 1;

    var dynamicId = 'dynamic_' + Date.now();
    var newContainerId = 'container_' + dynamicId;

    var data = '<div id="' + newContainerId + '"> <div class="row" id="' + dynamicId + '"> <div class="col-md-12 text-right d-flex justify-content-between"> <div class="serial-number px-3 mb-0"> <b>Sl. No.</b> ' + serialNumbers[containerId] + '</div><button onclick="deleteData(\'' + newContainerId + '\')" id="delete_data" type="button" style="background-color:transparent; border-color:transparent;"><i class="fa fa-trash-o" style="color:red; font-size:24px;"></i></button></div> <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no'+count+'[]" required></div></div> <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span><input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external'+count+'[]" required></div></div> <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="number" class="form-control" placeholder="Enter QTY" name="qty'+count+'[]" required></div></div> <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-cube"></i></span><input type="number" class="form-control" placeholder="Enter Packing" name="packing'+count+'[]" required></div></div><div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-dot-circle-o"></i> </span><input type="number" class="form-control" placeholder="Enter Pallets" name="pallets'+count+'[]" required></div></div> <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-line-chart"></i></span><input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales'+count+'[]" required></div></div><div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-ship"></i></span><select class="form-control" name="shipment_term'+count+'[]" required><option>Shipment Term</option><option value="FOB">FOB</option><option value="CIF">CIF</option><option value="DDU">DDU</option></select></div></div>  <div class="col-md-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-money"></i></span><input type="number" class="form-control" placeholder="Price" name="price'+count+'[]" required></div></div></div></div>';

    $('#' + containerId).prepend(data);

    // Update serial numbers based on existing fields
    updateSerialNumbers(containerId);

    serialNumbers[containerId]++;
}

function deleteData(containerId) {
    $('#' + containerId).remove();

    // Update serial numbers after deletion
    updateSerialNumbers(containerId);
}

function updateSerialNumbers(containerId) {
    $('#' + containerId + ' .serial-number').each(function(index) {
        $(this).html('<b>Sl. No.</b> ' + (index + 1));
    });
}


// var serialNumbers = {};

// function addData(containerId) {
//     serialNumbers[containerId] = serialNumbers[containerId] || 1;

//     var dynamicId = 'dynamic_' + Date.now();
//     var newContainerId = 'container_' + dynamicId;

//     var data = '<div id="' + newContainerId + '"> <div class="row" id="' + dynamicId + '"> <div class="col-md-12 text-right d-flex justify-content-between"> <div class="serial-number px-3 mb-0"> <b>Sl. No.</b> ' + serialNumbers[containerId] + '</div><button onclick="deleteData(\'' + newContainerId + '\')" id="delete_data" type="button" style="background-color:transparent; border-color:transparent;"><i class="fa fa-trash-o" style="color:red; font-size:24px;"></i></button></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span><input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="number" class="form-control" placeholder="Enter QTY" name="QTY"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-cube"></i></span><input type="text" class="form-control" placeholder="Enter Packing" name="packing"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-dot-circle-o"></i> </span><input type="text" class="form-control" placeholder="Enter Pallets" name="pallets"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-line-chart"></i></span><input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-ship"></i></span><select class="form-control"><option>Shipment Term</option><option value="FOB">FOB</option><option value="CIF">CIF</option><option value="DDU">DDU</option></select></div></div>  <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-money"></i></span><input type="text" class="form-control" placeholder="Price" name="price"></div></div></div></div>';

//     $('#' + containerId).prepend(data);

//     // Update serial numbers based on existing fields
//     updateSerialNumbers(containerId);

//     serialNumbers[containerId]++;
// }

// function deleteData(containerId) {
//     $('#' + containerId).remove();

//     // Update serial numbers after deletion
//     updateSerialNumbers(containerId);
// }

// function updateSerialNumbers(containerId) {
//     $('#' + containerId + ' .serial-number').each(function(index) {
//         $(this).html('<b>Sl. No.</b> ' + (index + 1));
//     });
// }



//     function addform() {
//         var dynamicId = 'dynamic_' + Date.now();
//         var containerId = 'container_' + dynamicId; 

//         var data = '<div id="' + containerId + '"><hr> <div class="row cardd" id="' + dynamicId + '">  <div class="col-sm-12 text-right"> <button onclick="deleteData(\'' + containerId + '\')" id="delete_data" type="button" style="background-color:transparent; border-color:transparent;"><i class="fa fa-trash-o" style="color:red; font-size:24px;"></i></button></div><div class="col-sm-4 input-container"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-user"></i></span><select class="form-control"><option>Aniket Patil</option><option>Jitendra Jadhav</option><option>Dinesh Mahajan</option></select></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-phone"></i></span><input type="text" class="form-control" placeholder="Enter Contact No" value="9876543256" name="contact_no"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-envelope"></i></span><input type="email" class="form-control" placeholder="Enter Email" value="aniket@gmail.com" name="email"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="number" class="form-control"  placeholder="Enter Shipment No." name="shipment_no"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" class="form-control" placeholder="Enter PO Received Date" name="received_date" onfocus="(this.type="date")" onblur="(this.type="text")"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" class="form-control" placeholder="Enter Dispatch Date" name="dispatch_ate" onfocus="(this.type="date")" onblur="(this.type="text")"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-comments"></i></span><input type="text" class="form-control" placeholder="Enter Remarks" name="remarks"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-text-width"></i></span><select class="form-control"><option>SIZE-FCL </option><option>AIR</option><option>LCL</option><option>20` FCL</option><option>40` FCL</option></select></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span><input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-list"></i></span><input type="number" class="form-control" placeholder="Enter QTY" name="QTY"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-cube"></i></span><input type="text" class="form-control" placeholder="Enter Packing" name="packing"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-dot-circle-o"></i> </span><input type="text" class="form-control" placeholder="Enter Pallets" name="pallets"></div></div> <div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-line-chart"></i></span><input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales"></div></div><div class="col-sm-4"><div class="input-icons"><span class="input-group-addon"><i class="fa fa-ship"></i></span><select class="form-control"><option>Shipment Term</option><option value="FOB">FOB</option><option value="CIF">CIF</option><option value="DDU">DDU</option></select></div></div></div><div class="col-sm-12 text-right"><a type="button" onclick="addData("addfieldsContainer3")" style="color:#4e73df; margin:5px;"> <u> Add More Fields </u></a></div><div id="addfieldsContainer3" class="col-md-12 add-fields-container"> </div></div></div> </div></div>';

//         $('#addforms').append(data);
//     }

//     function deleteData(containerId) {
//         $('#' + containerId).remove();
//     }
</script>


            <script>
                 function hideA(x) {
   if (x.checked) {    
     document.getElementById("frm").style.display = "block";
     document.getElementById("frm2").style.display = "none";
   }
 }

 function hideB(x) {
   if (x.checked) {
     document.getElementById("frm2").style.display = "block";
     document.getElementById("frm").style.display = "none";
   }
 }
            </script>