<?php 
class Orders_model extends CI_Model
{
	public function insert($table, $data)
    {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }


    public function allSampleRequestData($type)
    {
        $this->db->select('*');
        $this->db->from('sample_request');
        // $this->db->join('customer as c','g.customer_id = c.customer_id','left');
        return $this->db->get()->result_array();
    }

    public function getCustomerData(){
        $this->db->select('*');
        $this->db->from('customer');
        return $this->db->get()->result_array();
    }

    public function getPendingOrders($status){
        $this->db->where('status', $status);
        $this->db->select('status');
        $this->db->from('orders');
        return $this->db->get()->result_array();
    }

    public function getTransitDetails(){
        $this->db->where('status >', 0);
        $this->db->select('status');
        $this->db->from('orders');
        return $this->db->get()->result_array();
    }    
    
    public function getGeneralOrderData()
    {
        $this->db->select('*');
        $this->db->from('orders');
        $result = $this->db->get()->result_array();
        $outArr = array();
        foreach ($result as $row){
            $row['general_order'] = $this->getOrderData($row['order_id']);
            $outArr[] = $row;
        }
        return $outArr;
    } 


    public function getSpecificOrderData($searchOrderID)
    {
        $this->db->where('order_id', $searchOrderID);
        $this->db->select('*');
        $this->db->from('orders');
        $result = $this->db->get()->result_array();
        $outArr = array();
        foreach ($result as $row){
            $row['general_order'] = $this->getOrderData($row['order_id']);
            $outArr[] = $row;
        }
        return $outArr;
    } 
  
    public function getOrderData($order_id)
    {
        $this->db->where('order_id', $order_id);
        $this->db->select('*');
        $this->db->from('general_order as g');
        $this->db->join('customer as c','g.customer_id = c.customer_id','left');
        $result = $this->db->get()->result_array();
        $outArr = array();
        foreach ($result as $row){
            $row['shipment_order'] = $this->getShipmentOrder($row['general_order_id']);
            $outArr[] = $row;
        }
        return $outArr;
    } 
    
    public function getShipmentOrder($general_order_id){
        $this->db->where('general_order_id', $general_order_id);
        $this->db->select('*');
        $this->db->from('general_shipment_order');
        return $this->db->get()->result_array();
    }  
   
   
}