<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ManageStaff extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
		$this->load->model('Staff_model', 'staff', TRUE);
    }
    public function index()
    {
        $data['all_staff'] = $this->staff->getStaffData();
        // $length = count($data);
        $this->load->view('comman/header');
        $this->load->view('manage_staff', $data);
        $this->load->view('comman/footer');
    }
    public function addStaff()
    {
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $role = $this->input->post('role');
        $contact_no = $this->input->post('contact_no');
        $data = array(
            'name' => $name,
            'email' => $email,
            'role' => $role,
            'contact_no' => $contact_no
        );
        $this->db->query("INSERT INTO `staff`( `name`, `email`, `role` ,`contact_no`, `status`) VALUES (?, ?, ?, ?, ?)", array($name,
         $email, $role, $contact_no, "Active"));
         echo "<script>alert('Staff Add Successfully');
         window.location.href = '".site_url('ManageStaff')."';
        </script>";
    }

    public function editStaff()
    {
        $staff_id = $this->input->post('update_staff_id');
        $name = $this->input->post('update_name');
        $email = $this->input->post('update_email');
        $role = $this->input->post('update_role');
        $contact_no = $this->input->post('update_contact_no');
        $status = $this->input->post('update_status');
        $data = array(
            'staff_id' => $staff_id,
            'name' => $name,
            'email' => $email,
            'role' => $role,
            'contact_no' => $contact_no,
            'status' => $status
        );
        // print_r($data);
        $this->db->query("UPDATE `staff` SET `name`= ?, `email`= ?, `contact_no`= ?, `role`= ?, `status`= ? WHERE `staff_id`= ?", array($name, $email, $contact_no, $role, $status, $staff_id));
         echo "<script>alert('Staff edit Successfully');
         window.location.href = '".site_url('ManageStaff')."';
        </script>";
    }
}
?>