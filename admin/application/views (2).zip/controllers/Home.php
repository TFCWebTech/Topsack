<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->database();
		$this->load->model('Orders_model', 'orders', TRUE);
        $this->load->model('Staff_model', 'staff', TRUE);
    }

    public function index()
	{
        $data['all_sample_req'] = $this->orders->allSampleRequestData('SampleRequest');
        $data['sample_count'] = count($data['all_sample_req']);
        
        $data['all_staff'] = $this->staff->getStaffData();
        $data['all_staff'] = count($data['all_staff']);

        $status = 0;
        $data['all_pending_orders'] = $this->orders->getPendingOrders($status);
        $data['all_pending_count'] = count($data['all_pending_orders']);


        $data['all_transit_details'] = $this->orders->getTransitDetails();
        $data['all_transit_count'] = count($data['all_transit_details']);

        $data['all'] = $this->orders->getCustomerData();
        $this->load->view('comman/header');
		$this->load->view('index',$data);
        $this->load->view('comman/footer');
	}
    public function SampleChart()
    {
        $this->load->view('common/header');
        $this->load->view('sample_status_chart');
        $this->load->view('common/footer');
    }
  
    public function addSampleRequestData(){
        $full_name = $this->input->post('full_name');
        $contact_no = $this->input->post('contact_no');
        $email = $this->input->post('email');
        $sample_ref = $this->input->post('sample_ref');
        $sample_req_date = $this->input->post('sample_req_date');
        $tsp_ref = $this->input->post('tsp_ref');
        $qty = $this->input->post('qty');
        $address = $this->input->post('delivery_address');
        $estimated_dispatch_date = $this->input->post('estimated_dispatch_date');
        $confirmed_dispatch_date = $this->input->post('confirmed_dispatch_date');
        $courier_name = $this->input->post('courier_name');
        $awb = $this->input->post('awb');
        $remarks = $this->input->post('remarks');
    
    $data = array(
        'full_name' => $full_name,
        'contact_no' => $contact_no,
        'email' => $email,
        'sample_ref' => $sample_ref,
        'sample_req_date' => $sample_req_date,
        'tsp_ref' => $tsp_ref,
        'qty' => $qty,
        'address' => $address,
        'estimated_dispatch_date' => $estimated_dispatch_date,
        'confirmed_dispatch_date' => $confirmed_dispatch_date,
        'courier_name' => $courier_name,
        'awb' => $awb,
        'remarks' => $remarks
    );
    // print_r($data);
    $this->orders->insert('sample_request', $data);
    echo "<script>alert('Form Submitted Successfully');
    window.location.href = '".site_url('Home')."';
   </script>";
    }

    public function addGeneralOrderData(){
        
        $count = $this->input->post('count');

        date_default_timezone_set('Asia/Kolkata');
        $timeDate = date("Y-m-d h:i:s");
        $this->db->query("INSERT INTO `orders` (`created_at`) VALUES (?)", array($timeDate));
        
        $order_id = $this->db->insert_id();

        for($i = 0; $i <= $count; $i++){

            $customer_id = $this->input->post('full_name'.$i);
            if($customer_id !== null){
            $contact_no = $this->input->post('contact_no'.$i);
            $email = $this->input->post('customer_email'.$i);
            $shipment_no = $this->input->post('shipment_no'.$i);
            $po_received_date = $this->input->post('po_received_date'.$i);
            $dispatch_date = $this->input->post('dispatch_date'.$i);
            $remarks = $this->input->post('remarks'.$i);
            $size_fcl = $this->input->post('size_fcl'.$i);
            $my_order_no = $this->input->post('order_no'.$i);

            
            $this->db->query("INSERT INTO `general_order`(`customer_id`, `contact_no`, `email`, `shipment_no`, `po_received_data`, `dispatch_data`, `remarks`, `size-fcl`, `order_id`)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", array($customer_id, $contact_no, $email, $shipment_no, $po_received_date, $dispatch_date, $remarks, $size_fcl, $order_id));
            
            $general_order_id = $this->db->insert_id();

            for($j = 0; $j < sizeof($my_order_no); $j++){
                
                $order_no = $this->input->post('order_no'.$i)[$j];
                $dimension_external = $this->input->post('dimension_external'.$i)[$j];
                $qty = $this->input->post('qty'.$i)[$j];
                $packing = $this->input->post('packing'.$i)[$j];
                $pallets = $this->input->post('pallets'.$i)[$j];
                $bales = $this->input->post('pal_bales'.$i)[$j];
                $shipment_term = $this->input->post('shipment_term'.$i)[$j];
                $price = $this->input->post('price'.$i)[$j];

                $this->db->query("INSERT INTO `general_shipment_order`(`general_order_id`, `order_no`, `dimension_external`, `qty`, `packing`, `pallets`, `bales`, `shipment_term`, `price`)
                VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)", array($general_order_id, $order_no, $dimension_external, $qty, $packing, $pallets, $bales, $shipment_term, $price));
             
            }
         }
        }
        echo "<script>alert('order Submitted Successfully');
        window.location.href = '".site_url('Home')."';
    </script>";
    }


}
?>