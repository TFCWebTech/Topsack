<?php 
class Orders_model extends CI_Model
{
	public function insert($table, $data)
    {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }


    public function allSampleRequestData($type)
    {
        $this->db->select('*');
        $this->db->from('sample_request');
        return $this->db->get()->result_array();
    }

    public function getCustomerData(){
        $this->db->select('*');
        $this->db->from('customer');
        return $this->db->get()->result_array();
    }

    public function getPendingOrders(){
        $this->db->select('*');
        $this->db->from('general_order');
        return $this->db->get()->result_array();
    }

    public function getTransitDetails(){
        $this->db->select('*');
        $this->db->from('general_shipment_order');
        return $this->db->get()->result_array();
    }    


    
    public function getGeneralOrderData()
    {
        $this->db->select('*');
        $this->db->from('orders');
        $result = $this->db->get()->result_array();
        $outArr = array();
        foreach ($result as $row){
            $row['general_order'] = $this->getOrderData($row['order_id']);
            $outArr[] = $row;
        }
        return $outArr;
    } 

    public function getOrderData($order_id)
    {
        $this->db->where('order_id', $order_id);
        $this->db->select('*');
        $this->db->from('general_order');
        $result = $this->db->get()->result_array();
        $outArr = array();
        foreach ($result as $row){
            $row['shipment_order'] = $this->getShipmentOrder($row['general_order_id']);
            $outArr[] = $row;
        }
        return $outArr;
    } 
    
    public function getShipmentOrder($general_order_id){
        $this->db->where('general_order_id', $general_order_id);
        $this->db->select('*');
        $this->db->from('general_shipment_order');
        return $this->db->get()->result_array();
    }  
   
   
}