<?php 
class Login_model extends CI_Model
{
	public function checkUser($email, $password, $type)
    {
        // login.....
        $sql="SELECT * FROM `login` WHERE `email`='$email' AND `password`='$password' AND `type`='$type' ";
        // $sql="SELECT * FROM `login` WHERE `email`='admin@gmail.com' AND `password`='1234' ";
        $query = $this->db->query($sql);
        return $query->row_array();
    }

    public function checkemail($email)
    {
    	$sql="SELECT * FROM  `login`  WHERE `email`='$email' ";
        $query = $this->db->query($sql);
        return $query->row_array();
    }

    public function checkLoginToken($login_id, $token)
    {
        $sql="SELECT * FROM `login` WHERE `login_id`='$login_id' AND `token`='$token'";
        $query = $this->db->query($sql);
        return $query->row_array();
    }

    public function update($table, $colIdName, $id, $data)
    {
        $this->db->where($colIdName, $id);
        $result = $this->db->update($table, $data);
        return $result;
    }

}
?>