<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->database();
		$this->load->model('Login_model', 'login', TRUE);
    }

    public function index()
	{
        // $this->load->view('common/header');
		$this->load->view('login');
        // $this->load->view('common/footer');
	}

	public function userLogin()
	{
		$type = $this->input->post('type');
		$email = $this->input->post('email');            
        $password = $this->input->post('password');

        $enc_pass = md5($password);

		if($email != '' && $password != '' && $type != '' )
        {
            $check = $this->login->checkUser($email, $enc_pass, $type);
            
			
		if($check)
		{
            $login_id = $check['login_id'];
			$Start_session = array (
				'type'    => $type,
                'login_id' => $login_id
				
			);
            // print_r($Start_session);
			$this->session->set_userdata($Start_session);
            
			if($type == 'Shipment') {
			redirect('TransitDetais');
			} else {
				redirect('Home');
			}
		}
		else
		{
			$this->session->set_flashdata('error','Invalid Username/Email and password !..');
			redirect('Login');
		}
        
	}
	
}


	public function resetPassword($login_id, $token)
    {
        $data['check_token'] = $this->login->checkLoginToken($login_id, $token); 
		$data['login_id'] = $login_id;
		$data['token']=$token;
        $this->load->view('reset_password', $data);
    }
    public function generatePassword($login_id, $token)
    {
        $data['check_token'] = $this->login->checkLoginToken($login_id, $token); 
		$data['login_id'] = $login_id;
		$data['token']=$token;
        $this->load->view('generate_password', $data);
    }

	public function newPassword()
    {
        $token = $this->input->post('token');
        $login_id = $this->input->post('login_id');
        $password1 = $this->input->post('password1');
        $confirm_password2 = $this->input->post('password2');

        $password = md5($password1);
        $confirm_password = md5($confirm_password2);

        if($password!=$confirm_password)
        {
            $this->session->set_flashdata('error', 'Passwords did not match, Please try again!!!');
            redirect('Login/generate_password/'.$login_id.'/'.$token);
        }
        else
        {
            $data = array(
                'password' => $password,
                'token' => ''
            );
			// print_r($data);
			// echo $login_id;
            $this->login->update('login', 'login_id', $login_id, $data);
            $this->session->set_flashdata('success', 'Password Updated Successfully');
            redirect('Login');
        }
    }


    public function newPasswordGenerate()
    {
        $token = $this->input->post('token');
        $login_id = $this->input->post('login_id');
        $password1 = $this->input->post('password1');
        $confirm_password2 = $this->input->post('password2');

        $password = md5($password1);
        $confirm_password = md5($confirm_password2);

        if($password!=$confirm_password)
        {
            $this->session->set_flashdata('error', 'Passwords did not match, Please try again!!!');
            redirect('Login/generatePassword/'.$login_id.'/'.$token);
        }
        else
        {
            $data = array(
                'password' => $password,
                'token' => ''
            );
			// print_r($data);
			// echo $login_id;
            $this->login->update('login', 'login_id', $login_id, $data);
            $this->session->set_flashdata('success', 'Password generated Successfully');
            redirect('ManageStaff');
        }
    }

	public function forgot_pass()
    {
        $email = $this->input->post('send_email');
        $check_mail = $this->login->checkEmail($email);
		print_r($check_mail);
        if (empty($check_mail)) {
            $this->session->set_flashdata('error', "Invalid email");
            // redirect('Login');
        } else {
            $login_id = $check_mail['login_id'];
            $password = $check_mail['password'];

            //Random String
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $randomString = '';
            
            for ($i = 0; $i < 10; $i++) {
                $index = rand(0, strlen($characters) - 1);
                $randomString .= $characters[$index];
            }

            $updatedata = array(
                'token' => $randomString,
            );
            $this->login->update('login', 'login_id', $login_id, $updatedata);

            $mail_data['email'] = $check_mail['email'];
            $mail_data['login_id'] = $check_mail['login_id'];
            $mail_data['type'] = $check_mail['type'];
            $mail_data['token'] = $randomString;

            $config = Array(
				'protocol' => 'smtp',
				'smtp_host' => 'master.herosite.pro',
				'_smtp_auth' => TRUE,
				'smtp_port' => 465,
				'smtp_user' => 'admin@pressbro.com',
				'smtp_pass' => 'Vajra@5566',
				'smtp_crypto'   => 'ssl',
				'mailtype' => 'html',
				'charset' => 'utf-8'
			);
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
            $this->email->from('admin@pressbro.com', 'Topsack-Packaging');
            $this->email->to($email);
            $this->email->subject('Forgot Password!');
            
            $msg="<!DOCTYPE html>
                    <html>
                    <head>
                        <title></title>
                    </head>
                   <body style='border-top: 10px solid #3fa3df;text-align: center; color:#000 !important;'>
                       <div style='text-align: center;padding: 10px; background-color:white;'>
                            <img src='https://topsack.com/image/logo.png' style='width: 25%;vertical-align:middle'>
                        </div>
                        <div style='background-color: #fff; color:#000 !important; padding: 0% 10%; text-align: center;'>
                            <h1 align='center'>Reset Password</h1>
                            <h3 align='center'>Hello, ".$check_mail['type']."</h3>
                            <p style='color: #757272; text-align:'center' >To reset your password please click on the below button.</p>
                            <div style='text-align: center;'>
                                <a href='".site_url('Login/resetPassword/'.$mail_data['login_id'].'/'.$mail_data['token'])."'><button style='background-color: #3fa3df;border: 1px solid #3fa3df;color: #fff;padding: 10px;'> Reset Password</button></a>  
                            </div>
                        </div>
                        <p style='color: gray;padding: 10px;'>If you didn't make this request, ignore this email.</p>
                    </body>.
                    </html>";
            $this->email->message($msg);
            
            $result = $this->email->send();
            
            if($result) {
                $this->session->set_flashdata('success','Email Is Sended');
            } else {
                $this->session->set_flashdata('error','Email is not sended');
            }
        }
        redirect('Login');
    }
 	
 	public function Logout()
 	{
 		$this->session->unset_userdata('userData');
        $this->session->sess_destroy();
        redirect('Login');
 	}

}
?>