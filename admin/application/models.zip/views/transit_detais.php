<style>
  .form-control {
    padding: 3px !important;
}
</style>
                 <div class="container-fluid">
        
                            <div class="card-header py-3 d-flex justify-content-between">
                            <h3 class="m-0 font-weight-bold text-primary">Transit Order</h3>
                            <div>
                            <form
                                class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search ">
                                <div class="input-group  ">
                                    <input type="text" class="form-control bg-light border-1 small" placeholder="Search Order No..."
                                        aria-label="Search" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                 <section class="gradient-custom-2">
  <div class="container  h-100">
    <div class="row d-flex  align-items-center h-100">
    <div class="col-md-10 col-lg-8 col-xl-12 mt-4">
<div class="card card-stepper" >
<div class="card-header pt-2 pb-2 pl-3 pr-3">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-2">Order No: <span class="fw-bold text-body">001783</span></p>
<p class="text-muted mb-0">PO Date: <span class="fw-bold text-body">14/11/2023</span></p>
</div>



<div>
<h6 class="mb-0"> <a href="<?php echo site_url('PendingOrder/orderDetails'); ?>">View Details</a> </h6>
</div>
</div>
</div>
<div class="card-body p-4">
<div class=" mb-0 pb-0">
<div class="flex-fill d-flex justify-content-between">
<p class="text-muted">Customer Name: <span class="text-body">Rohit Jadhav</span></p>
<p class="text-muted">Email: <span class="text-body">rohit@gmail.com</span></p>
<p class="text-muted">Contact No: <span class="text-body">9875647839</span></p>
<p class="text-muted">Qty: <span class="text-body">03</span></p>
<p class="text-muted mb-0"> Shipment No: <span class="fw-bold text-body">12004356</span> </p>

</div>

</div>

</div>
<div class="card-footer p-3">
            <div class="d-flex justify-content-between">
            <h6 class="fw-normal mb-0"><a class="pointer" data-toggle="modal" data-target="#myModal" style="color:#4e73df;">Add Shipping Details</a></h6>
              <!-- <div class="border-start h-100"></div>
              <h6 class="fw-normal mb-0"><a href="#!">Complete Order</a></h6> -->
            </div>
          </div>
</div>
</div>
     
<div class="col-md-10 col-lg-8 col-xl-12 mt-4">
<div class="card card-stepper" >
<div class="card-header pt-2 pb-2 pl-3 pr-3">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-2">Order No: <span class="fw-bold text-body">001783</span></p>
<p class="text-muted mb-0">PO Date: <span class="fw-bold text-body">14/11/2023</span></p>
</div>



<div>
<h6 class="mb-0"> <a href="<?php echo site_url('PendingOrder/orderDetails'); ?>">View Details</a> </h6>
</div>
</div>
</div>
<div class="card-body p-4">
<div class=" mb-0 pb-0">
<div class="flex-fill d-flex justify-content-between">
<p class="text-muted">Customer Name: <span class="text-body">Rohit Jadhav</span></p>
<p class="text-muted">Email: <span class="text-body">rohit@gmail.com</span></p>
<p class="text-muted">Contact No: <span class="text-body">9875647839</span></p>
<p class="text-muted">Qty: <span class="text-body">03</span></p>
<p class="text-muted mb-0"> Shipment No: <span class="fw-bold text-body">12004356</span> </p>

</div>

</div>

</div>
<div class="card-footer p-3">
            <div class="d-flex justify-content-between">
            <h6 class="fw-normal mb-0"><a href="#!">Dispatch Order</a></h6>
              <div class="border-start h-100"></div>
              <h6 class="fw-normal mb-0"><a href="#!">Complete Order</a></h6>
            </div>
          </div>
</div>
</div>
      
<div class="col-md-10 col-lg-8 col-xl-12 mt-4">
<div class="card card-stepper" >
<div class="card-header pt-2 pb-2 pl-3 pr-3">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-2">Order No: <span class="fw-bold text-body">001783</span></p>
<p class="text-muted mb-0">PO Date: <span class="fw-bold text-body">14/11/2023</span></p>
</div>



<div>
<h6 class="mb-0"> <a href="<?php echo site_url('PendingOrder/orderDetails'); ?>">View Details</a> </h6>
</div>
</div>
</div>
<div class="card-body p-4">
<div class=" mb-0 pb-0">
<div class="flex-fill d-flex justify-content-between">
<p class="text-muted">Customer Name: <span class="text-body">Rohit Jadhav</span></p>
<p class="text-muted">Email: <span class="text-body">rohit@gmail.com</span></p>
<p class="text-muted">Contact No: <span class="text-body">9875647839</span></p>
<p class="text-muted">Qty: <span class="text-body">03</span></p>
<p class="text-muted mb-0"> Shipment No: <span class="fw-bold text-body">12004356</span> </p>

</div>

</div>

</div>
<div class="card-footer p-3">
            <div class="d-flex justify-content-between">
            <h6 class="fw-normal mb-0"><a href="#!">Completed Order</a></h6>
              
          </div>
</div>
</div>
<div class="col-md-10 col-lg-8 col-xl-12 mt-4">
<div class="card card-stepper" >
<div class="card-header pt-2 pb-2 pl-3 pr-3">
<div class="d-flex justify-content-between align-items-center">
<div>
<p class="text-muted mb-2">Order No: <span class="fw-bold text-body">001783</span></p>
<p class="text-muted mb-0">PO Date: <span class="fw-bold text-body">14/11/2023</span></p>
</div>



<div>
<h6 class="mb-0"> <a href="<?php echo site_url('PendingOrder/orderDetails'); ?>">View Details</a> </h6>
</div>
</div>
</div>
<div class="card-body p-4">
<div class=" mb-0 pb-0">
<div class="flex-fill d-flex justify-content-between">
<p class="text-muted">Customer Name: <span class="text-body">Rohit Jadhav</span></p>
<p class="text-muted">Email: <span class="text-body">rohit@gmail.com</span></p>
<p class="text-muted">Contact No: <span class="text-body">9875647839</span></p>
<p class="text-muted">Qty: <span class="text-body">03</span></p>
<p class="text-muted mb-0"> Shipment No: <span class="fw-bold text-body">12004356</span> </p>

</div>

</div>

</div>
<div class="card-footer p-3">
            <div class="d-flex justify-content-between">
            <h6 class="fw-normal mb-0">Order Completed</h6>
              
          </div>
</div>
</div>
    </div>
  </div>
</section>
                 </div>

            </div>
       
            <div class="modal fade" id="myModal" role="dialog">
             <div class="modal-dialog modal-lg">
    
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title">Add Shipping Details</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  
                </div>
                <div class="modal-body">
                  <div class="form">
                 
                  <form action="/action_page.php">
                    <div class="row">
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="TSP Invoice No">TSP Invoice No:</label>
                      <input type="number" class="form-control" placeholder="Enter TSP Invoice No" id="invoice_no">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Invoice Date">Invoice Date:</label>
                      <input type="date" class="form-control" placeholder="Enter Invoice Date" id="invoice_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Container No">Container No:</label>
                      <input type="number" class="form-control" placeholder="Enter Container No" id="container_no">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Shipping Line">Shipping Line:</label>
                      <select class="form-control">
                      <option >Select</option>
                          <option>MSC</option>
                          <option>CMA</option>
                          <option>HAPAG LLOYD</option>
                          <option>COSCO</option>
                          <option>MAERSK</option>
                          <option>OOCL</option>
                          <option>ZIM LINE</option>
                          <option>PIL</option>
                          <option>YML</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Shipping Line">Shipping Line:</label>
                      <select class="form-control">
                      <option >Select</option>
                          <option>ACC Bangalore</option>
                          <option>ICD Bangalore</option>
                          <option>Mangalore Port</option>
                          <option>Chennai Port</option>
                          <option>Ennore Port</option>
                          <option>Cochin Port</option>
                          <option>Navasheva Port</option>
                          
                        </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Departure Scheduled Date">Departure Scheduled Date (Indian Port) :</label>
                      <input type="date" class="form-control" placeholder="Departure Scheduled Date" id="scheduled_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Departure Actual Date">Departure Actual Date (Indian Port) :</label>
                      <input type="date" class="form-control" placeholder="Departure Actual Date" id="Actual_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Mother Port">Mother Port :</label>
                      <select class="form-control">
                      <option >Select</option>
                          <option>Colombo</option>
                          <option>Port Klang</option>
                          <option>Singapore</option>
                          <option>Salalah</option>
                          
                        </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Departure Scheduled Date">Departure Scheduled Date (Mother Port) :</label>
                      <input type="date" class="form-control" placeholder="Departure Scheduled Date" id="scheduled_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Departure Actual Date">Departure Actual Date (Mother Port) :</label>
                      <input type="date" class="form-control" placeholder="Departure Actual Date" id="Actual_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Port Of Dest">Port Of Dest :</label>
                      <select class="form-control">
                        <option >Select</option>
                          <option>Rotterdam</option>
                          <option>Hamburg</option>
                          <option>Antwerp</option>
                          <option>Barcelona</option>
                          <option>Genoa</option>
                          <option>Laspezia</option>
                          <option>Algeciras</option>
                          <option>Leharve</option>
                          <option>Marcille</option>
                          <option>Houston</option>
                          <option>Newyork</option>
                          <option>Savannah</option>
                          <option>Morrow G A</option>
                          <option>Halifax</option>
                          <option>Sydney</option>
                          <option>Fremantle</option>
                          <option>MelBourne</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Departure Actual Date">Expected Date Of Arrival At Destination :</label>
                      <input type="date" class="form-control" placeholder="Departure Expected Date Of Arrival At Destination" id="arrival_date">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                      <label for="Current Status">Current Status :</label>
                      <input type="text" class="form-control" placeholder="Enter Current Status" id="current_status">
                        </div>
                      </div>
                    </div>
                   
                <div class="modal-footer">
                 
                <button type="submit" class="btn btn-primary mt-3">Add</button>
                </div>
                  </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
  