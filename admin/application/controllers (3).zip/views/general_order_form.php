                      
                       
                       <div class="cardd " id="<?php echo $addcount; ?>">
                       <input type="text" name="countIncrement" id="countIncrement" value="<?php echo $countIncrement; ?>" hidden>
                            <div class="row" >
                                <div class="col-md-12 py-2 px-3 d-flex justify-content-between">           
                                <p class="serial-number" > <b>Shipment Sl. No. </b> <?php echo $addcount; ?></p>
                                
                                <a onclick="deleteData('<?php echo $addcount; ?>')" ><i class="fa fa-trash-o" style="color:red; font-size:24px;"></i></a>
                                </div>

                                <!-- <input type="text" class="serial-number" value="1" id="Shipment_no" > -->
                            <div class="col-md-4 input-container">           
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                        <select class="form-control" name="full_name<?php echo $countIncrement; ?>[]" onchange="customer_data(this.value, <?php echo $countIncrement; ?>)" id="customer_data<?php echo $countIncrement; ?>" required>
                                    <option >Select Name</option>
                                    <?php 
                                        foreach ($all as $value) { ?>
                                        <option value="<?php echo $value['customer_id']?>"><?php echo $value['customer_name']; ?></option>
                                        <?php }
                                        ?>
                                    </select>  
                                   </div>

                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Contact No" name="contact_no<?php echo $countIncrement; ?>[]" id="contact_no<?php echo $countIncrement; ?>" required>
                                   </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input type="email" class="form-control" placeholder="Enter Email" name="customer_email<?php echo $countIncrement; ?>[]" id="customer_email<?php echo $countIncrement; ?>" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="text" class="form-control"  placeholder="Enter Shipment No." name="shipment_no<?php echo $countIncrement; ?>[]" required>
                                </div>                                                                
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PO Received Date" name="po_received_date<?php echo $countIncrement; ?>[]"
                                onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dispatch Date" name="dispatch_date<?php echo $countIncrement; ?>[]"
                                onfocus="(this.type='date')" onblur="(this.type='text')" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-comments"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Remarks" name="remarks<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-text-width"></i></span>
                                <select class="form-control" name="size_fcl<?php echo $countIncrement; ?>[]" required>
                                    <option>SIZE-FCL </option>
                                    <option>AIR</option>
                                    <option>LCL</option>
                                    <option>20' FCL</option>
                                    <option>40' FCL</option>
                                    </select>
                                </div>
                                </div>
                                 </div>
                                <hr>
                                <div class="row">
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="text" class="form-control"  placeholder="Enter Order No / Item Code" name="order_no<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>
                              
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fas fa-arrows-alt-v"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Dimension-External" name="dimension_external<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                <input type="number" class="form-control" placeholder="Enter QTY" name="qty<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-cube"></i></span>
                                <input type="text" class="form-control" placeholder="Enter Packing" name="packing<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class='fa fa-dot-circle-o'></i></span>
                                <input type="text" class="form-control" placeholder="Enter Pallets" name="pallets<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>
                               
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-line-chart"></i></span>
                                <input type="text" class="form-control" placeholder="Enter PAL / Bales" name="pal_bales<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-ship"></i></span>
                                <select class="form-control" name="shipment_term<?php echo $countIncrement; ?>[]" required>
                                    <option>Shipment Term</option>
                                    <option value="FOB">FOB</option>
                                    <option value="CIF">CIF</option>
                                    <option value="DDU">DDU</option>
                                    </select>
                                </div>
                                </div>
                                <div class="col-md-4">
                                <div class="input-icons">
                                <span class="input-group-addon"><i class="fa fa-money"></i></span>
                                <input type="number" class="form-control" placeholder="Price" name="price<?php echo $countIncrement; ?>[]" required>
                                </div>
                                </div>
                                </div>
                          
                               <div class="row" >
                                <div class="col-md-12 text-right">
                                <a type="button" onclick="addData('addfieldsContainer<?php echo $addcount ?>')" style="color:#4e73df; margin:5px;"> <u> <b> Add More Fields </b></u></a>
                                </div>
                                <div id="addfieldsContainer<?php echo $addcount ?>" class="col-md-12 add-fields-container"> </div>
                                </div>
                                </div> 

                        
<script>

function deleteData(containerId) {
    $('#' + containerId).remove();

    updateSerialNumbers(containerId);
}

function updateSerialNumbers(containerId) {
    $('#' + containerId + ' .serial-number').each(function(index) {
        $(this).html('<b>Sl. No.</b> ' + (index + 1));
    });
}
 </script>



<script>
    function customer_data(selectedValue, countIncrement) {
        var selectedIndex = document.getElementById('customer_data' + countIncrement).selectedIndex;
        var contact_no = document.getElementById('contact_no' + countIncrement);
        var customer_email = document.getElementById('customer_email' + countIncrement);

        // Assuming your PHP array is named $all and contains the customer_contact and customer_email fields
        var customerData = <?php echo json_encode($all); ?>;

        // Make sure the selectedIndex is greater than 0 and within the bounds of the array
        if (selectedIndex > 0 && selectedIndex <= customerData.length) {
            // Set the contact number and email based on the selected customer's data
            contact_no.value = customerData[selectedIndex - 1].customer_contact;
            customer_email.value = customerData[selectedIndex - 1].customer_email;
        } else {
            // Handle the case where no option is selected or the index is out of bounds
            contact_no.value = '';
            customer_email.value = '';
        }
    }
</script>
